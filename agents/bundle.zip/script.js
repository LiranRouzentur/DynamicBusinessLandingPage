document.addEventListener('DOMContentLoaded', function() {
    const currentYearSpan = document.getElementById('currentYear');
    const backToTopButton = document.getElementById('backToTop');

    // Set the current year
    currentYearSpan.textContent = new Date().getFullYear();

    // Show/hide back to top button
    window.addEventListener('scroll', function() {
        if (window.scrollY > 100) {
            backToTopButton.classList.remove('hidden');
        } else {
            backToTopButton.classList.add('hidden');
        }
    });

    // Scroll to top functionality
    backToTopButton.addEventListener('click', function() {
        window.scrollTo({ top: 0, behavior: 'smooth' });
    });
});